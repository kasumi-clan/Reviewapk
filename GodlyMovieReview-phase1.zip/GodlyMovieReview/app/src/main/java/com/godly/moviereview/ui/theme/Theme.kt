package com.godly.moviereview.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val GodlyBg = Color(0xFF060A12)
val GodlySurface = Color(0xFF0D1524)
val GodlySurfaceHigh = Color(0xFF14203A)
val GodlyBlue = Color(0xFF3B82F6)
val GodlyBlueLight = Color(0xFF7DB4FF)
val GodlyText = Color(0xFFF1F5FF)
val GodlyTextDim = Color(0xFF9FB0CC)
val GodlyOk = Color(0xFF34D399)
val GodlyWarn = Color(0xFFF59E0B)
val GodlyDanger = Color(0xFFEF4444)

private val GodlyScheme = darkColorScheme(
    primary = GodlyBlue,
    onPrimary = Color.White,
    secondary = GodlyBlueLight,
    background = GodlyBg,
    onBackground = GodlyText,
    surface = GodlySurface,
    onSurface = GodlyText,
    surfaceVariant = GodlySurfaceHigh,
    onSurfaceVariant = GodlyTextDim,
    error = GodlyDanger
)

@Composable
fun GodlyTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = GodlyScheme, typography = Typography(), content = content)
}
