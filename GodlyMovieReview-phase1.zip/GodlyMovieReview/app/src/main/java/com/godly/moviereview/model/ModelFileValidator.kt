package com.godly.moviereview.model

import java.io.File
import java.security.MessageDigest

object ModelFileValidator {
    enum class Status { OK, MISSING, BAD_FORMAT, SIZE_MISMATCH, CHECKSUM_MISMATCH }

    data class Result(val status: Status, val checksumVerified: Boolean, val message: String)

    fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input ->
            val buf = ByteArray(256 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                digest.update(buf, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    /**
     * Kiểm tra tệp: tồn tại, kích thước (nếu manifest có), 4 byte đầu (magic) và SHA-256 (nếu manifest có).
     * Đây chưa phải kiểm tra nạp model vào runtime (llama.cpp / whisper.cpp) — việc đó thuộc Giai đoạn 2.
     */
    fun validate(spec: ModelSpec, file: File): Result {
        if (!file.isFile || file.length() == 0L) {
            return Result(Status.MISSING, false, "Không thấy tệp model hoặc tệp rỗng")
        }
        val expectedSize = spec.sizeBytes
        if (expectedSize != null && expectedSize != file.length()) {
            return Result(Status.SIZE_MISMATCH, false, "Kích thước ${file.length()} B khác kỳ vọng $expectedSize B")
        }
        val magic = spec.fileMagic
        if (magic != null) {
            val head = ByteArray(magic.length)
            val read = file.inputStream().use { it.read(head) }
            if (read != head.size || String(head, Charsets.ISO_8859_1) != magic) {
                return Result(Status.BAD_FORMAT, false, "Đầu tệp không đúng định dạng $magic")
            }
        }
        val expectedHash = spec.sha256
        if (expectedHash != null) {
            val actual = sha256(file)
            return if (actual.equals(expectedHash, ignoreCase = true)) {
                Result(Status.OK, true, "Khớp SHA-256")
            } else {
                Result(Status.CHECKSUM_MISMATCH, false, "SHA-256 không khớp với manifest")
            }
        }
        return Result(Status.OK, false, "Đã kiểm tra định dạng/kích thước; manifest chưa có checksum nên chưa xác minh SHA-256")
    }
}
