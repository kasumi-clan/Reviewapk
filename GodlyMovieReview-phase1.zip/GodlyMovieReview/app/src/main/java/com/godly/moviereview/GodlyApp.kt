package com.godly.moviereview

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.godly.moviereview.model.ModelRepository
import com.godly.moviereview.storage.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AppContainer(app: Application) {
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val database: AppDatabase = AppDatabase.create(app)
    val models = ModelRepository(app, database.modelDao(), appScope)

    init {
        appScope.launch { models.reconcile() }
    }
}

class GodlyApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}

fun AndroidViewModel.container(): AppContainer = getApplication<GodlyApp>().container
