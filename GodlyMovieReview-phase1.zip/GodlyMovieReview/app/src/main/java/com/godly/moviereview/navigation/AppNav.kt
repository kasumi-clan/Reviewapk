package com.godly.moviereview.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.godly.moviereview.ui.home.HomeScreen
import com.godly.moviereview.ui.importvideo.ImportScreen
import com.godly.moviereview.ui.models.ModelManagerScreen
import com.godly.moviereview.ui.settings.SettingsScreen
import com.godly.moviereview.ui.theme.GodlyBg

object Routes {
    const val HOME = "home"
    const val IMPORT = "import"
    const val MODELS = "models"
    const val SETTINGS = "settings"
}

@Composable
fun AppNav() {
    val nav = rememberNavController()
    NavHost(
        navController = nav,
        startDestination = Routes.HOME,
        modifier = Modifier
            .fillMaxSize()
            .background(GodlyBg)
    ) {
        composable(Routes.HOME) {
            HomeScreen(
                onNewProject = { nav.navigate(Routes.IMPORT) },
                onOpenModels = { nav.navigate(Routes.MODELS) },
                onOpenSettings = { nav.navigate(Routes.SETTINGS) }
            )
        }
        composable(Routes.IMPORT) { ImportScreen(onBack = { nav.popBackStack() }) }
        composable(Routes.MODELS) { ModelManagerScreen(onBack = { nav.popBackStack() }) }
        composable(Routes.SETTINGS) {
            SettingsScreen(
                onBack = { nav.popBackStack() },
                onOpenModels = { nav.navigate(Routes.MODELS) }
            )
        }
    }
}
