package com.godly.moviereview

import com.godly.moviereview.model.ModelDownloader
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Before
import org.junit.Test
import java.io.File
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.nio.file.Files
import kotlin.concurrent.thread

/** Kiểm thử tải thật qua HTTP cục bộ (ServerSocket), gồm cả tiếp tục tải bằng Range. */
class ModelDownloaderTest {
    private lateinit var server: ServerSocket
    private lateinit var dir: File
    private val payload = ByteArray(600_000) { (it % 251).toByte() }

    @Volatile
    private var lastRange: String? = null

    @Before
    fun setUp() {
        dir = Files.createTempDirectory("models").toFile()
        server = ServerSocket(0, 10, InetAddress.getByName("127.0.0.1"))
        thread(isDaemon = true) {
            while (!server.isClosed) {
                val socket = try {
                    server.accept()
                } catch (e: Exception) {
                    break
                }
                try {
                    handle(socket)
                } catch (e: Exception) {
                    // client đóng kết nối sớm: bỏ qua
                }
            }
        }
    }

    @After
    fun tearDown() {
        server.close()
        dir.deleteRecursively()
    }

    private fun handle(socket: Socket) {
        socket.use { s ->
            val reader = s.getInputStream().bufferedReader(Charsets.ISO_8859_1)
            var range: String? = null
            while (true) {
                val line = reader.readLine() ?: break
                if (line.isEmpty()) break
                if (line.startsWith("Range:", ignoreCase = true)) {
                    range = line.substringAfter(':').trim()
                }
            }
            lastRange = range

            val start = range?.removePrefix("bytes=")?.substringBefore('-')?.toIntOrNull()
            val head: String
            val body: ByteArray
            if (start != null) {
                body = payload.copyOfRange(start, payload.size)
                head = "HTTP/1.1 206 Partial Content\r\n" +
                    "Content-Range: bytes $start-${payload.size - 1}/${payload.size}\r\n" +
                    "Content-Length: ${body.size}\r\n" +
                    "Connection: close\r\n\r\n"
            } else {
                body = payload
                head = "HTTP/1.1 200 OK\r\n" +
                    "Content-Length: ${body.size}\r\n" +
                    "Connection: close\r\n\r\n"
            }
            val out = s.getOutputStream()
            out.write(head.toByteArray(Charsets.ISO_8859_1))
            out.write(body)
            out.flush()
        }
    }

    private fun url() = "http://127.0.0.1:${server.localPort}/m.bin"

    @Test
    fun downloadsFullFile() {
        runBlocking {
            val file = ModelDownloader(dir).download(url(), "m.bin") { }
            assertArrayEquals(payload, file.readBytes())
            assertFalse(File(dir, "m.bin.part").exists())
        }
    }

    @Test
    fun resumesFromPartFile() {
        runBlocking {
            File(dir, "m.bin.part").writeBytes(payload.copyOfRange(0, 100_000))
            val file = ModelDownloader(dir).download(url(), "m.bin") { }
            assertEquals("bytes=100000-", lastRange)
            assertArrayEquals(payload, file.readBytes())
        }
    }
}
