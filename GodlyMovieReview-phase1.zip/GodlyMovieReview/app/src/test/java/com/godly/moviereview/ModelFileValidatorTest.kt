package com.godly.moviereview

import com.godly.moviereview.model.ModelFileValidator
import com.godly.moviereview.model.ModelFileValidator.Status
import com.godly.moviereview.model.ModelRole
import com.godly.moviereview.model.ModelSpec
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File
import java.nio.file.Files

class ModelFileValidatorTest {
    private lateinit var dir: File

    @Before
    fun setUp() {
        dir = Files.createTempDirectory("validator").toFile()
    }

    @After
    fun tearDown() {
        dir.deleteRecursively()
    }

    private fun spec(sha: String? = null, size: Long? = null, magic: String? = "GGUF") = ModelSpec(
        id = "t", name = "t", role = ModelRole.LLM, version = "1",
        fileName = "t.gguf", url = "https://example.invalid/t", approxSizeMb = null,
        sizeBytes = size, sha256 = sha, license = "test", sourceName = "test",
        sourceNote = null, fileMagic = magic
    )

    private fun fileWith(bytes: ByteArray): File = File(dir, "t.gguf").also { it.writeBytes(bytes) }

    private val good = "GGUF".toByteArray() + ByteArray(100) { it.toByte() }

    @Test
    fun okWithoutChecksumIsNotMarkedVerified() {
        val r = ModelFileValidator.validate(spec(), fileWith(good))
        assertEquals(Status.OK, r.status)
        assertFalse(r.checksumVerified)
    }

    @Test
    fun okWithMatchingChecksumIsVerified() {
        val f = fileWith(good)
        val r = ModelFileValidator.validate(spec(sha = ModelFileValidator.sha256(f)), f)
        assertEquals(Status.OK, r.status)
        assertTrue(r.checksumVerified)
    }

    @Test
    fun wrongChecksumIsRejected() {
        val r = ModelFileValidator.validate(spec(sha = "0".repeat(64)), fileWith(good))
        assertEquals(Status.CHECKSUM_MISMATCH, r.status)
    }

    @Test
    fun wrongMagicIsBadFormat() {
        val r = ModelFileValidator.validate(spec(), fileWith("<html>error page</html>".toByteArray()))
        assertEquals(Status.BAD_FORMAT, r.status)
    }

    @Test
    fun wrongSizeIsRejected() {
        val r = ModelFileValidator.validate(spec(size = 5), fileWith(good))
        assertEquals(Status.SIZE_MISMATCH, r.status)
    }

    @Test
    fun missingFileIsReported() {
        val r = ModelFileValidator.validate(spec(), File(dir, "nope.gguf"))
        assertEquals(Status.MISSING, r.status)
    }
}
