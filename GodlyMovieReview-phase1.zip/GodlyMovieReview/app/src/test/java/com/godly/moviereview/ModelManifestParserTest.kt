package com.godly.moviereview

import com.godly.moviereview.model.ModelManifestParser
import com.godly.moviereview.model.ModelRole
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class ModelManifestParserTest {
    private fun manifestText(): String {
        val candidates = listOf(File("../model-config/model_manifest.json"), File("model-config/model_manifest.json"))
        val f = candidates.firstOrNull { it.isFile }
        assertNotNull("Không tìm thấy model_manifest.json", f)
        return f!!.readText()
    }

    @Test
    fun parsesAllModels() {
        val specs = ModelManifestParser.parse(manifestText())
        assertEquals(5, specs.size)
        assertEquals(
            setOf("qwen25-05b-q4", "whisper-tiny", "whisper-base", "tts-vi", "translation-en-vi"),
            specs.map { it.id }.toSet()
        )
        assertEquals(ModelRole.LLM, specs.first { it.id == "qwen25-05b-q4" }.role)
    }

    @Test
    fun unconfiguredModelsHaveNoDownloadUrl() {
        val specs = ModelManifestParser.parse(manifestText())
        assertFalse(specs.first { it.id == "tts-vi" }.configured)
        assertFalse(specs.first { it.id == "translation-en-vi" }.configured)
    }

    @Test
    fun configuredModelsUseHttpsAndHaveFileName() {
        val specs = ModelManifestParser.parse(manifestText()).filter { it.configured }
        assertTrue(specs.isNotEmpty())
        specs.forEach {
            assertTrue(it.url!!.startsWith("https://"))
            assertNotNull(it.fileName)
        }
    }

    @Test
    fun sha256IsNullOr64HexChars() {
        ModelManifestParser.parse(manifestText()).forEach {
            val h = it.sha256
            assertTrue(h == null || Regex("[0-9a-f]{64}").matches(h))
        }
    }
}
