#!/usr/bin/env python3
"""Kiểm tra nguồn model trong model-config/model_manifest.json bằng Internet.

Với mỗi model có url: gửi HEAD (không theo chuyển hướng) rồi đọc kích thước và SHA-256.
Hugging Face trả SHA-256 của tệp LFS trong header `x-linked-etag`.
  python3 scripts/verify_models.py            # chỉ báo cáo
  python3 scripts/verify_models.py --write    # ghi sizeBytes và sha256 vào manifest

Không đoán giá trị: nếu máy chủ không cung cấp thì để nguyên null và báo rõ.
"""
import argparse
import json
import re
import sys
import urllib.error
import urllib.request
from pathlib import Path

MANIFEST = Path(__file__).resolve().parent.parent / "model-config" / "model_manifest.json"


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):  # noqa: D401
        return None


def inspect(url, timeout=30):
    """Trả về dict: status, size, sha256 (None nếu máy chủ không cung cấp)."""
    opener = urllib.request.build_opener(NoRedirect)
    req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "GodlyMovieReview-verify/0.1"})
    try:
        resp = opener.open(req, timeout=timeout)
        status, headers = resp.status, resp.headers
    except urllib.error.HTTPError as e:  # 3xx cũng rơi vào đây vì NoRedirect
        status, headers = e.code, e.headers
    size = headers.get("x-linked-size") or headers.get("Content-Length")
    etag = (headers.get("x-linked-etag") or "").strip('"')
    sha = etag.lower() if re.fullmatch(r"[0-9a-fA-F]{64}", etag) else None
    return {"status": status, "size": int(size) if size and size.isdigit() else None, "sha256": sha}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--write", action="store_true", help="ghi sizeBytes/sha256 vào manifest")
    args = ap.parse_args()

    data = json.loads(MANIFEST.read_text(encoding="utf-8"))
    failed = False
    for m in data["models"]:
        if not m.get("url"):
            print(f"[bỏ qua] {m['id']}: chưa cấu hình nguồn")
            continue
        try:
            info = inspect(m["url"])
        except Exception as e:  # noqa: BLE001
            print(f"[LỖI] {m['id']}: {e}")
            failed = True
            continue
        ok = info["status"] in (200, 301, 302, 303, 307, 308)
        print(f"[{'ok' if ok else 'LỖI'}] {m['id']}: HTTP {info['status']}, size={info['size']}, sha256={info['sha256']}")
        failed |= not ok
        if ok and args.write:
            if info["size"]:
                m["sizeBytes"] = info["size"]
            if info["sha256"]:
                m["sha256"] = info["sha256"]
    if args.write and not failed:
        MANIFEST.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print("Đã ghi manifest.")
    sys.exit(1 if failed else 0)


if __name__ == "__main__":
    main()
