#!/usr/bin/env python3
"""Kiểm tra cấu trúc dự án GODLY AI MOVIE REVIEW (chạy được không cần Internet).

Kiểm tra: tệp bắt buộc, model_manifest.json hợp lệ, không có URL giả/mật khẩu ký
trong mã, không có TODO/FIXME trong mã nguồn chính, không nhúng model vào app/.
Thoát mã 1 nếu có lỗi.
"""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

REQUIRED = [
    "settings.gradle.kts",
    "build.gradle.kts",
    "gradle.properties",
    "app/build.gradle.kts",
    "app/src/main/AndroidManifest.xml",
    "app/src/main/java/com/godly/moviereview/MainActivity.kt",
    "app/src/main/java/com/godly/moviereview/GodlyApp.kt",
    "app/src/main/java/com/godly/moviereview/model/ModelRepository.kt",
    "app/src/main/java/com/godly/moviereview/model/ModelDownloader.kt",
    "model-config/model_manifest.json",
    ".github/workflows/build-apk.yml",
    "README.md",
    "IMPLEMENTATION_STATUS.md",
]
MODEL_EXT = {".gguf", ".onnx", ".bin", ".ggml", ".tflite"}
FAKE_URL = re.compile(r"example\.(com|org|net)|placeholder|your[-_ ]?url|todo", re.I)

errors = []


def err(msg):
    errors.append(msg)


for rel in REQUIRED:
    p = ROOT / rel
    if not p.is_file() or p.stat().st_size == 0:
        err(f"Thiếu hoặc rỗng: {rel}")

manifest_path = ROOT / "model-config" / "model_manifest.json"
if manifest_path.is_file():
    try:
        data = json.loads(manifest_path.read_text(encoding="utf-8"))
        ids = set()
        for m in data["models"]:
            mid = m.get("id", "?")
            if mid in ids:
                err(f"manifest: id trùng {mid}")
            ids.add(mid)
            for key in ("id", "name", "role", "version", "license", "sourceName"):
                if not m.get(key):
                    err(f"manifest[{mid}]: thiếu '{key}'")
            url = m.get("url")
            if url:
                if not url.startswith("https://"):
                    err(f"manifest[{mid}]: url phải là https")
                if FAKE_URL.search(url):
                    err(f"manifest[{mid}]: url trông như giá trị giả")
                if not m.get("fileName"):
                    err(f"manifest[{mid}]: có url nhưng thiếu fileName")
            sha = m.get("sha256")
            if sha is not None and not re.fullmatch(r"[0-9a-f]{64}", str(sha)):
                err(f"manifest[{mid}]: sha256 không hợp lệ")
    except Exception as e:  # noqa: BLE001
        err(f"manifest không đọc được: {e}")

for path in (ROOT / "app" / "src").rglob("*"):
    if path.suffix in MODEL_EXT:
        err(f"Không được nhúng model vào app: {path.relative_to(ROOT)}")

for path in (ROOT / "app" / "src" / "main").rglob("*.kt"):
    text = path.read_text(encoding="utf-8")
    rel = path.relative_to(ROOT)
    for n, line in enumerate(text.splitlines(), 1):
        if re.search(r"\b(TODO|FIXME)\b", line):
            err(f"{rel}:{n}: còn TODO/FIXME trong mã chính")
    if text.count("{") != text.count("}"):
        err(f"{rel}: số dấu {{ và }} không khớp")
    if text.count("(") != text.count(")"):
        err(f"{rel}: số dấu ( và ) không khớp")

for path in ROOT.rglob("*"):
    if path.is_file() and path.suffix in {".kts", ".kt", ".yml", ".py", ".json", ".properties"} and ".git" not in path.parts:
        t = path.read_text(encoding="utf-8", errors="ignore")
        if re.search(r"(storePassword|keyPassword)\s*=\s*\"[^\"]+\"", t):
            err(f"{path.relative_to(ROOT)}: có vẻ chứa mật khẩu ký cứng")

if errors:
    print("KIỂM TRA THẤT BẠI:")
    for e in errors:
        print(" -", e)
    sys.exit(1)
print("verify_project: OK")
